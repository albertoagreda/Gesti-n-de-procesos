package actividad1_tema3; /**
 * OrdenarNumeros.java
 * -------------------
 * Lee de la entrada estándar una secuencia indeterminada de tokens y
 * extrae los que sean números enteros, los ordena de menor a mayor y
 * los escribe en la salida estándar (un número por línea).
 *
 * Uso:
 *   java OrdenarNumeros
 *
 * Ejemplo con tubería:
 *   java Aleatorios 50 | java OrdenarNumeros
 *
 * Comportamiento en casos especiales:
 * - Ignora tokens no numéricos y escribe un aviso por stderr para cada
 *   token inválido.
 * - Si no se reciben números, informa y termina sin bloqueo.
 *
 * @author Alberto agredano
 * @version 1.0
 */
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;


public class OrdenarNumeros {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        List<Integer> lista = new ArrayList<>();

        // Leemos todos los tokens disponibles en stdin.
        while (sc.hasNext()) {
            String token = sc.next();
            try {
                int v = Integer.parseInt(token);
                lista.add(v);
            } catch (NumberFormatException e) {
                // No numérico: lo ignoramos, pero indicamos por stderr.
                System.err.println("Aviso: token no numérico ignorado -> '" + token + "'");
            }
        }
        sc.close();

        // Si no hay números, lo indicamos y salimos.
        if (lista.isEmpty()) {
            System.out.println("No se recibieron números. Fin de ejecución.");
            return;
        }

        // Ordenamos y mostramos (un valor por línea para claridad).
        Collections.sort(lista);
        for (int n : lista) {
            System.out.println(n);
        }
        System.out.flush();
    }
}
