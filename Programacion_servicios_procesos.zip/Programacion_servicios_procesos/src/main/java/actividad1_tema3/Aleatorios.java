package actividad1_tema3; /**
 * Aleatorios.java
 * ----------------
 * Genera una cantidad de números aleatorios entre 0 y 100 y los escribe
 * en la salida estándar (separados por espacios). Se puede pasar como
 * argumento el número de valores a generar.
 *
 * Uso:
 *   java Aleatorios         (genera 40 números)
 *   java Aleatorios 100     (genera 100 números)
 *
 * Está diseñado para usarse con tuberías, por ejemplo:
 *   java Aleatorios | java OrdenarNumeros
 *
 * @author Alberto agredano
 * @version 1.0
 */
import java.util.Random;

public class Aleatorios {
    public static void main(String[] args) {
        int count = 40; // valor por defecto
        if (args.length >= 1) {
            try {
                int c = Integer.parseInt(args[0]);
                if (c > 0) count = c;
            } catch (NumberFormatException e) {
                System.err.println("Aviso: argumento inválido para count. Usando 40.");
            }
        }

        Random rnd = new Random();
        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < count; i++) {
            int n = rnd.nextInt(101); // genera 0..100
            sb.append(n);
            if (i < count - 1) sb.append(' ');
        }

        // Escribimos una sola línea con todos los números y forzamos flush.
        System.out.println(sb.toString());
        System.out.flush();
    }
}
